import { useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { useLanguageStore } from "../store/language.store";
import { useSettingsStore } from "../store/settings.store";
import { mobileNavItems } from "../constants/navigation";
import { APP_IMAGES, getImageUrl } from "../constants/app-images";
import { X, Info, Phone, Newspaper, Languages, MapPin } from "lucide-react";

const menuLinks = [
  { labelKey: "nav.about", to: "/about", icon: Info },
  { labelKey: "nav.contact", to: "/contact", icon: Phone },
  { labelKey: "mobileNav.blog", to: "/blog", icon: Newspaper },
];

export default function MobileBottomNav() {
  const { t } = useTranslation();
  const direction = useLanguageStore((s) => s.direction);
  const location = useLocation();
  const settings = useSettingsStore((s) => s.settings);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const isRTL = direction === "rtl";

  return (
    <>
      <nav
        dir={direction}
        className="fixed bottom-0 left-0 right-0 z-50 block md:hidden"
      >
        <div className="relative mx-auto flex h-[72px] w-full items-center justify-between rounded-t-[22px] bg-white px-4 shadow-[0_-4px_20px_rgba(0,0,0,0.08)]">
          {mobileNavItems.map((item) => {
            const Icon = item.icon;

            const isActive =
              item.to === "/"
                ? location.pathname === "/"
                : location.pathname.startsWith(item.to);

            const baseItemClass =
              "relative flex h-full flex-1 flex-col items-center justify-center text-center transition";

            if (item.isMenu) {
              return (
                <button
                  key={item.to}
                  type="button"
                  onClick={() => setSidebarOpen(true)}
                  className={baseItemClass}
                >
                  <div
                    className={`flex items-center justify-center transition ${
                      isActive
                        ? "absolute -top-[22px] h-[64px] w-[64px] rounded-full bg-white text-[var(--brand-primary-color)] shadow-[0_8px_24px_rgba(0,0,0,0.08)]"
                        : "text-[#9CA3AF]"
                    }`}
                  >
                    <Icon size={28} strokeWidth={2.2} />
                  </div>

                  <span
                    className={`text-[12px] font-bold leading-none transition ${
                      isActive ? "mt-[30px] text-[var(--brand-primary-color)]" : "mt-1 text-[#9CA3AF]"
                    }`}
                  >
                    {t(item.labelKey)}
                  </span>
                </button>
              );
            }

            return (
              <NavLink key={item.to} to={item.to} className={baseItemClass}>
                <div
                  className={`flex items-center justify-center transition ${
                    isActive
                      ? "absolute -top-[22px] h-[64px] w-[64px] rounded-full bg-white text-[var(--brand-primary-color)] shadow-[0_8px_24px_rgba(0,0,0,0.08)]"
                      : "text-[#9CA3AF]"
                    }`}
                >
                  <Icon size={28} strokeWidth={2.2} />
                </div>

                <span
                  className={`text-[12px] font-bold leading-none transition ${
                    isActive ? "mt-[30px] text-[var(--brand-primary-color)]" : "mt-1 text-[#9CA3AF]"
                  }`}
                >
                  {t(item.labelKey)}
                </span>
              </NavLink>
            );
          })}
        </div>
      </nav>

      {sidebarOpen && (
        <div
          className="fixed inset-0 z-[60] bg-black/40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <div
        className={`fixed top-0 bottom-0 z-[70] w-[75vw] max-w-[320px] bg-white shadow-2xl transition-transform duration-300 md:hidden ${
          isRTL ? "right-0" : "left-0"
        } ${
          sidebarOpen
            ? "translate-x-0"
            : isRTL
              ? "translate-x-full"
              : "-translate-x-full"
        }`}
      >
        <div className="flex h-full flex-col">
          <div className="flex items-center justify-between px-5 pt-5 pb-3">
            <img
              src={getImageUrl(settings?.logo ?? null) || APP_IMAGES.LOGO}
              alt="Knoz Cars"
              className="h-20 w-auto object-contain"
              loading="lazy"
            />
            <button
              type="button"
              onClick={() => setSidebarOpen(false)}
              className="text-[#34495E]"
            >
              <X size={22} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto px-5 pb-6">
            <div className="flex flex-col gap-1">
              {menuLinks.map((link) => {
                const LinkIcon = link.icon;
                const isActive = location.pathname === link.to;

                return (
                  <NavLink
                    key={link.to}
                    to={link.to}
                    onClick={() => setSidebarOpen(false)}
                    className={`flex items-center gap-3 rounded-xl px-4 py-3.5 text-[15px] font-bold leading-none transition ${
                      isActive
                        ? "bg-[var(--brand-primary-color)]/10 text-[var(--brand-primary-color)]"
                        : "text-[#07111F] hover:bg-[#F0F2F5]"
                    }`}
                  >
                    <LinkIcon size={20} strokeWidth={2.2} />
                    {t(link.labelKey)}
                  </NavLink>
                );
              })}
            </div>

            <div className="mt-6 border-t border-[#D9DEE7] pt-4 flex flex-col gap-1">
              <span className="flex items-center gap-3 rounded-xl px-4 py-3.5 text-[15px] font-bold leading-none text-[#07111F]">
                <MapPin size={20} strokeWidth={2.2} />
                {t("topbar.locationValue")}
              </span>
              <button
                type="button"
                onClick={() => {
                  const { language, setLanguage } = useLanguageStore.getState();
                  setLanguage(language === "en" ? "ar" : "en");
                  setSidebarOpen(false);
                }}
                className="flex w-full items-center gap-3 rounded-xl px-4 py-3.5 text-[15px] font-bold leading-none text-[#07111F] transition hover:bg-[#F0F2F5]"
              >
                <Languages size={20} strokeWidth={2.2} />
                {t("topbar.language")}
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
