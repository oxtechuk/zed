export interface ILoadingSlotProps {}
