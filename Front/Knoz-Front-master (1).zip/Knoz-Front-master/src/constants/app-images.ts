import { API_ORIGIN } from "./axios.constants";

const STORAGE_PREFIX = `${API_ORIGIN}/storage/`;

export function getImageUrl(path: string | null): string {
  if (!path) return "";
  if (path.startsWith("http://") || path.startsWith("https://")) {
    return path.replace(/([^:]\/)\//g, "$1");
  }
  return `${STORAGE_PREFIX}${path}`;
}

export const APP_IMAGES = {
  LOGO: "/images/logo_without_bg.png",
  HOME_HERO: "/images/home_hero.png",
  EID: "/images/eid.png",
  CAR1: "/images/car1.png",
  CAR_PLACEHOLDER: "/images/car-placeholder.png",
  BRAND_PLACEHOLDER: "/images/brand-placeholder.svg",
  RIYAL: "/images/riyal.svg",
  CAR_ICON: "/images/car icons/car.svg",
  FUEL_ICON: "/images/car icons/fuel.svg",
  GEARBOX_ICON: "/images/car icons/tabler_manual-gearbox.svg",
  SEAT_ICON: "/images/car icons/seat.svg",
  BG_IMAGE: "/images/offers-section-bg.png",
  ALL_CARS_OFFER_IMAGE: "/images/all-cars-offer-page.png",
  COMPARE_IMAGE: "/images/compre-image.png",
  OFFER1: "/images/offer1.png",
  OFFER_PLACEHOLDER: "/images/offer1.png",
  BLOG_PLACEHOLDER: "/images/blog.png",
  BLOG_AUTHOR_PLACEHOLDER: "/images/blogs/author.png",
  AVATAR_PLACEHOLDER: "/images/avatar.png",
  LOCATION_PLACEHOLDER: "/images/locations/riyadh.png",
  SOCIAL_TIKTOK: "/images/social/tiktok.png",
  SOCIAL_FACEBOOK: "/images/social/facebook.png",
  SOCIAL_INSTAGRAM: "/images/social/instagram.png",
} as const;
